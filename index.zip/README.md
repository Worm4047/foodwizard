# Foodwizard

### FoodWizard operates on the principle:- 
`Every one needs to cook and the easiest and the cheapest way is to cook with what you already have`

Foodwizard is your kitchen buddy.Combining the power of Alexa lambda functions, Foodwizard gives you the ability to retrieve your favorite recipes through commands and conversations making the entire process of information exchange verbal.

# Features and Functionalities

## Recipe search - By Recipe Name

The good old method of recipe search.Just ask alexa to search for the dish using it's name eg:-

	`Alexa ask foodwizard how cheese sandwich are made`
## Step by step guidance

Foodwizard guides you through the entire process of creating the dish.

## Searching possible dish combinations using the ingredients available with you.

Foodwizard finds possible dish for you to make using the ingredients present at you disposal

## Dishes of various cuisines and category

Food wizard gives you the facility to choose from a wide variety of cuisines like Indian,French,Italian,Mexican,Chinese,Greek etc.
Each cuisine can further be exploited for it's dessert,drinks,main dishes,appetizers and bread.
Thus providing an overall awesome experience for your kitchen time.

# How FoodWizard helps 'COMMON MAN' ?

Foodwizard creates the entire process of creating dishes seamless and verbal, thereby allowing users to interact with the device even while making the dishes, this way they won't have to `Touch` electronic devices whil cooking.
FoodWizard guides you through the entire process and repeats any step as and when needed.
FoodWizard exposes the user to vast arena of Recipes all around the globe at the same time providing required ingredients and steps to make the dish.

